/* App JS: auth (IndexedDB), search (local data from uploaded PDF), and offline-ready behavior.
   Illness/tips are embedded below — extracted from the uploaded PDF (see footer for file citation). :contentReference[oaicite:2]{index=2}
*/

/* ---------- Simple IndexedDB wrapper ---------- */
const DB = (function(){
  const NAME = 'telehealth-db';
  const VERSION = 1;
  let db;
  function open(){
    return new Promise((res, rej) => {
      if(db) return res(db);
      const rq = indexedDB.open(NAME, VERSION);
      rq.onupgradeneeded = e => {
        const idb = e.target.result;
        if(!idb.objectStoreNames.contains('users')) idb.createObjectStore('users', { keyPath:'email' });
        if(!idb.objectStoreNames.contains('profile')) idb.createObjectStore('profile', { keyPath:'email' });
        if(!idb.objectStoreNames.contains('queue')) idb.createObjectStore('queue', { keyPath:'id' });
      };
      rq.onsuccess = e => { db = e.target.result; res(db); };
      rq.onerror = e => rej(e.target.error);
    });
  }
  function tx(store, mode='readonly'){
    return open().then(db=>db.transaction(store, mode).objectStore(store));
  }
  return {
    put(store, obj){ return tx(store, 'readwrite').then(s=> new Promise((r,rej)=>{ const rq=s.put(obj); rq.onsuccess=()=>r(obj); rq.onerror=()=>rej(rq.error) })) },
    get(store, key){ return tx(store).then(s=> new Promise((r,rej)=>{ const rq=s.get(key); rq.onsuccess=()=>r(rq.result); rq.onerror=()=>rej(rq.error) })) },
    getAll(store){ return tx(store).then(s=> new Promise((r,rej)=>{ const rq=s.getAll(); rq.onsuccess=()=>r(rq.result); rq.onerror=()=>rej(rq.error) })) },
    del(store, key){ return tx(store,'readwrite').then(s=> new Promise((r,rej)=>{ const rq=s.delete(key); rq.onsuccess=()=>r(); rq.onerror=()=>rej(rq.error) })) },
    clear(store){ return tx(store,'readwrite').then(s=> new Promise((r,rej)=>{ const rq=s.clear(); rq.onsuccess=()=>r(); rq.onerror=()=>rej(rq.error) })) }
  };
})();

/* ---------- Simple crypto: SHA-256 for password hashing ---------- */
async function sha256(str){
  const enc = new TextEncoder();
  const data = enc.encode(str);
  const hash = await crypto.subtle.digest('SHA-256', data);
  const hex = Array.from(new Uint8Array(hash)).map(b=>b.toString(16).padStart(2,'0')).join('');
  return hex;
}

/* ---------- Illness data (extracted from uploaded PDF) ---------- */
/* NOTE: This dictionary was created from your uploaded PDF /mnt/data/health_issues_recovery_extended.pdf. :contentReference[oaicite:3]{index=3}
   Key names are lowercased for forgiving search. */
const HEALTH_DATA = {
  "headache": "He, rest in dark room, reduce screen time.",
  "migraine": "Cold compress, avoid triggers, rest, hydration.",
  "dizziness": "Sit/lie down, drink ORS, eat something light.",
  "fatigue": "Sleep 7–8 hours, hydration, light diet, reduce stress.",
  "fever": "Hydrate, paracetamol as per label, rest.",
  "body pain": "Warm compress, light stretching, hydration.",
  "cold": "Warm fluids, steam inhalation, ginger-honey.",
  "cough": "Warm water, steam, avoid cold drinks.",
  "sore throat": "Salt-water gargle, warm tea, avoid ice.",
  "blocked nose": "Steam inhalation, warm compress.",
  "sinus pain": "Steam, hydration, avoid cold air.",
  "sneezing": "Avoid dust, keep environment clean.",
  "allergy (mild)": "Avoid allergen, wear mask, keep room clean.",
  "throat irritation": "Warm fluids, avoid spicy food.",
  "dry mouth": "Hydrate frequently.",
  "indigestion": "Warm water, avoid oily food, small meals.",
  "gas/bloating": "Ginger tea, avoid carbonated drinks.",
  "acidity": "Cold milk, avoid spicy food, eat small meals.",
  "constipation": "Fiber-rich diet, hydration, walking.",
  "loose motion": "ORS, banana-curd-rice diet, avoid dairy.",
  "stomach ache": "Warm water, light food, rest.",
  "food poisoning (mild)": "ORS, hydration, bland diet.",
  "nausea": "Ginger tea, fresh air, small meals.",
  "vomiting": "ORS, rest stomach, avoid heavy foods.",
  "back pain": "Warm compress, posture correction.",
  "neck pain": "Gentle stretching, warm compress.",
  "shoulder pain": "Rest, warm compress.",
  "muscle cramps": "Electrolytes, stretching.",
  "joint pain": "Warm compress, light movement.",
  "eye strain": "20-20-20 rule, blink more.",
  "red eyes": "Cold splash, avoid rubbing.",
  "dry eyes": "Artificial tears, blink frequently.",
  "watery eyes": "Cold compress, avoid irritants.",
  "ear pain": "Warm compress, avoid q-tips.",
  "ear wax": "Use ear drops, avoid inserting objects.",
  "runny nose": "Stay hydrated, steam.",
  "dry nose": "Apply petroleum jelly.",
  "nose bleed": "Pinch nose, lean forward, stay calm.",
  "skin rash": "Aloe vera, avoid scratching.",
  "acne": "Cleanse twice daily, avoid oily food.",
  "pimples": "Avoid touching, use mild face wash.",
  "dandruff": "Use anti-dandruff shampoo.",
  "hair fall": "Oil massage, avoid harsh chemicals.",
  "dry skin": "Moisturize, hydrate.",
  "oily skin": "Wash face twice, avoid greasy food.",
  "sunburn": "Aloe vera gel, cool compress.",
  "tanning": "Use sunscreen, aloe vera.",
  "chapped lips": "Lip balm, hydrate.",
  "cracked heels": "Warm water soak, moisturize.",
  "itchy skin": "Cold compress, avoid hot showers.",
  "fungal infection (mild)": "Keep dry, antifungal powder.",
  "stress": "Deep breathing, short breaks.",
  "anxiety": "Breathing exercises, grounding.",
  "overthinking": "Journaling, structured routine.",
  "irritability": "Rest, hydration.",
  "sleep deprivation": "Sleep routine, avoid screens.",
  "insomnia": "Warm milk, dim lights.",
  "low motivation": "Set small goals, sunlight.",
  "brain fog": "Hydrate, eat balanced meals.",
  "loneliness": "Talk to family/friends.",
  "mood swings": "Balanced diet, routine.",
  "anger issues": "Breathing, meditation.",
  "burnout": "Short breaks, rest.",
  "study stress": "Pomodoro, timed study.",
  "work stress": "Micro-breaks, hydration.",
  "poor posture": "Stretching, straighten spine.",
  "neck stiffness": "Warm compress, stretches.",
  "low stamina": "Light exercise routine.",
  "weak immunity": "Fruits, good sleep.",
  "vitamin deficiency": "Balanced diet, supplements.",
  "iron deficiency": "Spinach, jaggery.",
  "weight gain": "Walk 30 mins daily.",
  "weight loss": "High-calorie healthy foods.",
  "sugar cravings": "Fruit snacks, hydrate.",
  "junk food addiction": "Healthy replacements.",
  "dehydration": "ORS, coconut water.",
  "overexertion": "Rest, electrolytes.",
  "muscle soreness": "Warm bath, stretching.",
  "knee pain": "Avoid stairs, warm compress.",
  "foot pain": "Foot soak, rest.",
  "heel pain": "Stretching, supportive shoes.",
  "wrist pain": "Rest, avoid strain.",
  "hand cramps": "Massage, hydration.",
  "motion sickness": "Ginger, fresh air.",
  "light sensitivity": "Rest eyes, reduce light.",
  "sound sensitivity": "Quiet room, rest.",
  "high stress workload": "Take regular breaks, manage tasks.",
  "low blood pressure (mild)": "Drink salt water ORS.",
  "high blood pressure (mild)": "Deep breathing, reduce salt.",
  "mild chest tightness (non-cardiac)": "Rest, slow breathing.",
  "mild dehydration headache": "Drink ORS immediately.",
  "weakness after illness": "Eat bananas, soups, rest.",
  "seasonal fever": "Hydrate, rest.",
  "dry cough": "Warm water, honey.",
  "wet cough": "Steam inhalation.",
  "gassy stomach": "Ajwain water.",
  "mild ibs": "Avoid trigger foods.",
  "acute stress reaction": "Sit, breathe slowly.",
  "mild panic episode": "Deep breathing, grounding.",
  "lack of appetite": "Eat small portions.",
  "overeating": "Light walk after meals.",
  "fast heartbeat from anxiety": "Slow breathing.",
  "nail weakness": "Calcium-rich foods.",
  "hair thinning": "Protein-rich diet.",
  "dark circles": "Sleep, hydrate.",
  "swollen eyes": "Cold compress.",
  "foot swelling": "Elevate feet.",
  "hand swelling": "Gentle movement.",
  "neck lump (mild swelling)": "Warm compress.",
  "chest congestion": "Steam inhalation.",
  "sweating excessively": "Drink electrolytes.",
  "cold sweats": "Hydrate, rest.",
  "hot flashes": "Cool water, loose clothes.",
  "acne scars": "Aloe vera.",
  "pigmentation": "Sunscreen daily.",
  "itchy scalp": "Use mild shampoo.",
  "skin dry patches": "Moisturize frequently.",
  "hair breakage": "Avoid heat styling.",
  "throat dryness": "Warm water.",
  "allergic cough": "Avoid dust.",
  "dry lips": "Lip balm, hydration.",
  "blisters": "Keep clean, dry.",
  "minor wounds": "Clean with water.",
  "bruises": "Cold compress.",
  "insect bite": "Apply ice.",
  "mosquito bite": "Apply calamine.",
  "mild sun allergy": "Avoid sun exposure.",
  "mild food allergy": "Avoid trigger food.",
  "low energy in morning": "Hydrate, light stretch.",
  "afternoon fatigue": "Short walk.",
  "numb hands (temporary)": "Shake hands gently.",
  "numb feet (temporary)": "Walk slowly."
  /* If the original file contains more entries, they can be appended here. */
};

/* ---------- UI helpers ---------- */
const $ = id => document.getElementById(id);
function show(view){
  document.querySelectorAll('.view').forEach(v=>v.style.display='none');
  document.querySelectorAll('.sideBtn').forEach(b=>b.classList.remove('active'));
  const btn = document.querySelector(`.sideBtn[data-view="${view}"]`);
  if(btn) btn.classList.add('active');
  $(`view-${view}`).style.display = 'block';
}

/* ---------- Wire UI ---------- */
document.addEventListener('DOMContentLoaded', async () => {
  // elements
  const authView = $('authView'), appView = $('appView');
  const showLogin = $('showLogin'), showRegister = $('showRegister');
  const loginForm = $('loginForm'), registerForm = $('registerForm');
  const btnLogout = $('btnLogout');
  const avatar = $('avatar'), userName = $('userName'), userEmail = $('userEmail');
  const profileForm = $('profileForm'), profileName = $('profileName'), profilePhone = $('profilePhone');
  const searchInput = $('searchInput'), searchBtn = $('searchBtn'), resultArea = $('resultArea');
  const notesList = $('notesList'), queueList = $('queueList'), recordsList = $('recordsList');
  const btnClearLocal = $('btnClearLocal');

  // small helper to toggle views
  function showAppFor(user){
    authView.style.display='none';
    appView.style.display='flex';
    btnLogout.style.display='inline-block';
    avatar.textContent = (user.name||'User').split(' ').map(s=>s[0]).slice(0,2).join('').toUpperCase();
    userName.textContent = user.name || 'User';
    userEmail.textContent = user.email;
    refreshLists();
    // show default dashboard view
    document.querySelectorAll('.view').forEach(v=>v.style.display='none');
    $('view-dashboard').style.display='block';
  }

  // tabs on the left
  document.querySelectorAll('.sideBtn').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const v = btn.dataset.view;
      document.querySelectorAll('.view').forEach(x=>x.style.display='none');
      document.querySelector(`#view-${v}`).style.display='block';
      document.querySelectorAll('.sideBtn').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  // show login/register toggle
  showLogin.addEventListener('click', ()=>{ showLogin.classList.add('active'); showRegister.classList.remove('active'); loginForm.style.display='block'; registerForm.style.display='none'; });
  showRegister.addEventListener('click', ()=>{ showRegister.classList.add('active'); showLogin.classList.remove('active'); loginForm.style.display='none'; registerForm.style.display='block'; });

  // registration
  registerForm.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const name = $('regName').value.trim();
    const email = $('regEmail').value.trim().toLowerCase();
    const pass = $('regPassword').value;
    if(!name || !email || !pass){ alert('Please fill all fields'); return; }
    const existing = await DB.get('users', email);
    if(existing){ alert('Account with that email already exists locally'); return; }
    const hash = await sha256(pass);
    const user = { email, name, passHash: hash, createdAt: Date.now() };
    await DB.put('users', user);
    // also create empty profile doc
    await DB.put('profile', { email, name, phone:'', updatedAt: Date.now() });
    alert('Account created locally — you can now login.');
    registerForm.reset();
    showLogin.click();
  });

  // login
  loginForm.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const email = $('loginEmail').value.trim().toLowerCase();
    const pass = $('loginPassword').value;
    if(!email || !pass){ alert('Provide credentials'); return; }
    const user = await DB.get('users', email);
    if(!user){ alert('No local account found — register first.'); return; }
    const hash = await sha256(pass);
    if(hash !== user.passHash){ alert('Invalid password'); return; }
    // set "session" in memory (for demo)
    window.__teleUser = user;
    showAppFor(user);
  });

  // logout
  btnLogout.addEventListener('click', ()=>{
    delete window.__teleUser;
    appView.style.display='none';
    authView.style.display='block';
    btnLogout.style.display='none';
  });

  // profile save
  profileForm.addEventListener('submit', async (e)=>{
    e.preventDefault();
    const user = window.__teleUser;
    if(!user) return alert('Not logged in');
    const p = { email: user.email, name: $('profileName').value.trim(), phone: $('profilePhone').value.trim(), updatedAt: Date.now() };
    await DB.put('profile', p);
    user.name = p.name;
    await DB.put('users', user);
    alert('Profile saved locally');
    userName.textContent = user.name;
    refreshLists();
  });

  // search
  function normalize(q){ return q.trim().toLowerCase(); }
  searchBtn.addEventListener('click', doSearch);
  searchInput.addEventListener('keydown', (e)=>{ if(e.key==='Enter') doSearch(); });

  function renderResult(title, tip){
    resultArea.innerHTML = '';
    if(!tip){
      resultArea.innerHTML = `<div class="card"><h3>${title}</h3><p class="muted">No tip found in local dataset. Try a different query or check spelling.</p></div>`;
      return;
    }
    const html = `<div class="card">
      <h3>${title}</h3>
      <p class="muted">Recovery tip (from your uploaded PDF):</p>
      <div style="margin-top:10px;padding:12px;border-radius:8px;border:1px dashed #eef2ff">${tip}</div>
      <div style="margin-top:12px">
        <button id="saveNote" class="primary">Save as note</button>
      </div>
    </div>`;
    resultArea.innerHTML = html;
    $('saveNote').addEventListener('click', async ()=>{
      const user = window.__teleUser;
      const note = { id: 'note-'+Math.random().toString(36).slice(2,9), email: user.email, title, tip, createdAt: Date.now() };
      await DB.put('queue', note); // store note in queue for local persistence
      alert('Saved locally');
      refreshLists();
    });
  }

  function doSearch(){
    const q = normalize(searchInput.value);
    if(!q) return alert('Type an illness name (e.g., Headache)');
    // 1) exact match
    if(HEALTH_DATA[q]) return renderResult(capitalize(q), HEALTH_DATA[q]);
    // 2) partial match search
    const keys = Object.keys(HEALTH_DATA);
    const found = keys.filter(k => k.includes(q) || k.replace(/\W/g,'').includes(q.replace(/\W/g,'')));
    if(found.length===1) return renderResult(capitalize(found[0]), HEALTH_DATA[found[0]]);
    if(found.length>1){
      resultArea.innerHTML = `<div class="card"><h3>Multiple results</h3><div class="list">${found.slice(0,20).map(k=>`<div class="item"><strong>${capitalize(k)}</strong><div class="muted small">${HEALTH_DATA[k]}</div><div style="margin-top:6px"><button data-key="${k}" class="ghost small">View</button></div></div>`).join('')}</div></div>`;
      resultArea.querySelectorAll('button[data-key]').forEach(b=>b.addEventListener('click', ()=>{ const k=b.dataset.key; renderResult(capitalize(k), HEALTH_DATA[k]); }));
      return;
    }
    // 3) fuzzy: try splitting words
    const parts = q.split(/\s+/);
    const fuzzy = keys.find(k => parts.every(p => k.includes(p)));
    if(fuzzy) return renderResult(capitalize(fuzzy), HEALTH_DATA[fuzzy]);

    renderResult(capitalize(q), null);
  }

  // helper to capitalize key for display
  function capitalize(s){ return s.split(' ').map(p=>p.charAt(0).toUpperCase()+p.slice(1)).join(' '); }

  // lists
  async function refreshLists(){
    const notes = await DB.getAll('queue') || [];
    // show latest 10 as notes
    notesList.innerHTML = notes.slice(-10).reverse().map(n=>`<div class="item"><strong>${n.title || n.id}</strong><div class="muted small">${n.tip ? n.tip : (n.email ? 'Saved record' : '')}</div></div>`).join('') || '<div class="muted small">No notes</div>';
    queueList.innerHTML = notes.slice(-10).reverse().map(q=>`<div class="item"><div class="muted small">${new Date(q.createdAt || Date.now()).toLocaleString()}</div><div>${(q.title||q.id)}</div></div>`).join('') || '<div class="muted small">Queue empty</div>';
    const profiles = await DB.getAll('profile');
    const recs = (profiles || []).map(p=>`<div class="item"><strong>${p.name || p.email}</strong><div class="muted small">${p.phone || ''}</div></div>`).join('');
    recordsList.innerHTML = recs || '<div class="muted small">No profiles saved locally</div>';
    // set profile form fields if logged in
    const user = window.__teleUser;
    if(user){
      const p = await DB.get('profile', user.email);
      if(p){
        $('profileName').value = p.name || '';
        $('profilePhone').value = p.phone || '';
      }
    }
  }

  // clear local
  btnClearLocal.addEventListener('click', async ()=>{
    if(!confirm('Clear all local data (users, profiles, queue)?')) return;
    await DB.clear('users'); await DB.clear('profile'); await DB.clear('queue');
    alert('Cleared local DB. Reload to start fresh.');
    location.reload();
  });

  // small helper to reference views by id
  window.$ = (id) => document.getElementById(id);
  // create view id mapping for show()
  document.querySelectorAll('.view').forEach(v=>{
    const vid = v.id.replace('view-','');
    window[`view-${vid}`] = v;
  });

  // register service worker for offline
  if('serviceWorker' in navigator){
    navigator.serviceWorker.register('sw.js').then(()=>console.log('sw ok')).catch(e=>console.warn(e));
  }

  // Expose search for quick testing in console
  window.teleSearch = doSearch;

  // If an account exists locally, prefill login email to help testing
  const users = await DB.getAll('users');
  if(users && users.length>0){
    $('loginEmail').value = users[0].email;
  }

});
const CACHE = 'telehealth-cache-v1';
const ASSETS = [
  '/', '/index.html', '/styles.css', '/app.js', '/manifest.json'
];

self.addEventListener('install', ev => {
  ev.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(()=>self.skipWaiting()));
});
self.addEventListener('activate', ev => { ev.waitUntil(self.clients.claim()); });

self.addEventListener('fetch', ev => {
  const req = ev.request;
  if(req.method !== 'GET') return;
  // navigation -> serve index.html (app shell)
  if(req.mode === 'navigate'){
    ev.respondWith(caches.match('/index.html').then(res => res || fetch(req)));
    return;
  }
  ev.respondWith(caches.match(req).then(res => res || fetch(req).then(r=>{ if(req.url.startsWith(self.location.origin)){ caches.open(CACHE).then(c=>c.put(req, r.clone())); } return r; }).catch(()=>caches.match('/index.html'))));
});

